<?php $__env->startSection('content'); ?>
    <section class="ftco-section ftco-no-pt ftco-no-pb">
        <div class="container">
            <div class="row d-flex">
                <div class="col-lg-12 px-md-5 py-5" style="width:100%">
                    <div class="row pt-md-4">

                        <?php
                        // Function to detect if the text is in Urdu
                        function isUrdu($text) {
                            return preg_match('/[\x{0600}-\x{06FF}]/u', $text);
                        }
                        ?>

                        <style>
                            .english-alignment {
                                text-align: left;
                                direction: ltr;
                            }
                            .urdu-alignment {
                                text-align: right;
                                direction: rtl;
                            }
                        </style>

                        <section class="ftco-section ftco-no-pt ftco-no-pb">
                            <div class="container">
                            <div class="row d-flex" style="width: 100%">
                            <div class="col-xl-12 px-md-5 py-5" col-xl-4 sidebar ftco-animate bg-light pt-5 fadeInUp ftco-animated">
                            <div class="row pt-md-4">

                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-12" style="width: 100%;">
                            <div class="blog-entry-2 ftco-animate">
                            <a href="single.html" class="img img-2"
                                style="background-image: url(<?php echo e(url('public/blog/'.$row->blog_image )); ?>);"></a>
                            <div class="text pt-4">
                            <h3 class="heading <?php echo e(isUrdu($row->blog_title) ? 'urdu-alignment' : 'english-alignment'); ?>"><a href="#"><?php echo e($row->blog_title); ?></a></h3>
                            <p  style="max-height: 60px; overflow: hidden; margin-bottom: 5px;"><?php echo $row->blog_long_desc; ?></p>
                            <div class="author mb-4 d-flex align-items-center">
                            <a href="#" class="img" style="background-image: url(images/person_1.jpg);"></a>
                            <div class="ml-3 info">
                            <span>Written by</span>
                            <h3><a href="#">Masood Khan</a>, <span><?php echo e($row->created_at); ?></span></h3>

                            </div>
                            </div>
                            </div>
                            </div>
                            </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <div class="comment-form-wrap pt-5 w-100">
                            <h3 class="mb-5">Leave a comment</h3>
                            <form action="#" class="p-3 p-md-5 bg-light">
                                <div class="form-group">
                                    <label for="name">Name *</label>
                                    <input type="text" class="form-control" id="name">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email *</label>
                                    <input type="email" class="form-control" id="email">
                                </div>
                                <div class="form-group">
                                    <label for="website">Website</label>
                                    <input type="url" class="form-control" id="website">
                                </div>
                                <div class="form-group">
                                    <label for="message">Message</label>
                                    <textarea name="" id="message" cols="30" rows="10" class="form-control"></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" value="Post Comment" class="btn py-3 px-4 btn-primary">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\urdublog\resources\views/single.blade.php ENDPATH**/ ?>