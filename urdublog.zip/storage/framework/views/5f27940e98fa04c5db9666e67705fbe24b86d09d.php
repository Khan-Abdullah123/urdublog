
<?php $__env->startSection('title', "Dashboard"); ?>
<?php $__env->startSection('content'); ?>

<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>

        <div class="row">
           
            <div class="col-xl-12">
                
            </div>
        </div>

    </div>
</main>
<script>



</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UrduBlog\resources\views/Admin/Dashboard.blade.php ENDPATH**/ ?>