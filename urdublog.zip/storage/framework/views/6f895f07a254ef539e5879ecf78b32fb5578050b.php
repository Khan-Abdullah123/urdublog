<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body {
  background-color: black;
  fonst-size:30px;
  color: white;
}



 @media (max-width: 600px) {
            .mobile-class {
                padding-left: 20px;

                padding-right: 10px;
            	background-color:white;
                color:red;

            }
        }
</style>
</head>
<body class="mobile-class">

<p >Resize the browser window. When the width of this document is 600 pixels or less, the background-color is "lightblue", otherwise it is "lightgreen".
Resize the browser window. When the width of this document is 600 pixels or less, the background-color is "lightblue", otherwise it is "lightgreen".Resize the browser window. When the width of this document is 600 pixels or less, the background-color </p>

</body>
</html>


<?php /**PATH C:\xampp\htdocs\urdublog\resources\views/mediatest.blade.php ENDPATH**/ ?>